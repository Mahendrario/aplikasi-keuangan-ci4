<?php
namespace App\Controllers;

class Test extends BaseController
{
    public function index()
    {
        echo "<h1>Halo Dunia! Routing berhasil.</h1>";
    }
}